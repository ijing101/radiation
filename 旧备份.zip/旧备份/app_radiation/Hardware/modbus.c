#include "main.h"
#include "Hx711.h"
#include "modbus.h"
#include "iap_trigger.h"
#include "wdg.h"

MODBUS modbus;
uint16_t Reg[128];

void Modbus_Init(void)
{
    modbus.myadd        = 0x01;
    modbus.myadd_cached = 0x01;
    modbus.bound        = 9600;
    modbus.timrun       = 0;
    modbus.Host_Sendtime  = 0;
    modbus.Host_time_flag = 0;
}

/**
 * @brief  �������� IEEE754 ����������� 16 λ�Ĵ�����������ǰ��Modbus ������
 * @param  f   ��ת���ĸ�����
 * @param  hi  ������� 16 λ
 * @param  lo  ������� 16 λ
 */
static void float_to_regs(float f, uint16_t *hi, uint16_t *lo)
{
    union {
        float    f;
        uint32_t u;
    } conv;

    conv.f = f;
    *hi = (uint16_t)(conv.u >> 16);        /* �� 16 λ */
    *lo = (uint16_t)(conv.u & 0xFFFFU);    /* �� 16 λ */
}

/**
 * @brief  ���� Modbus ���ּĴ����еķ������ֵ������ + �����ͣ�
 * @note   ÿ����ѭ�����á�Reg[0~3] ֻ����ѭ��д���� Modbus_Func3 �ж���
 *          ����ͬ�߳�ִ�У��������жϾ�����
 */
void Update_Radiation_Regs(void)
{
    uint16_t hi, lo;
    float    rad_float;

    /* ���ͷ���ֵ��HX711 �������������̱궨���޷� 0~1268�� */
    Reg[0] = (uint16_t)Param_Radi_1[0];

    /* ԭʼ����ֵ���� 16 λ������λ������/����ã� */
    Reg[3] = (uint16_t)Radi_Back[0];

    /* �������ֵ = ����ֵ / ����ϵ����ռ Reg[1](��) + Reg[2](��) �����Ĵ��� */
    rad_float = (float)Param_Radi_1[0] / RADIATION_FLOAT_SCALE;
    float_to_regs(rad_float, &hi, &lo);
    Reg[1] = hi;
    Reg[2] = lo;

    /* Mirror calibration params into Reg[] for Func3 read-back */
    Reg[REG_PARAM_RADI] = (uint16_t)Param_Adj_Radi[0];
    Reg[REG_PARAM_DIR]  = (uint16_t)Param_Adj_Dir[0];
}











static void Modbus_Exception(uint8_t func, uint8_t code)
{
    uint16_t crc, i = 0;

    /* Խ��/�Ƿ����󷵻ر�׼ Modbus �쳣֡��������|0x80 + �쳣�� */
    modbus.sendbuf[i++] = modbus.myadd;
    modbus.sendbuf[i++] = func | 0x80;
    modbus.sendbuf[i++] = code;
    crc = Modbus_CRC16(modbus.sendbuf, i);
    modbus.sendbuf[i++] = (uint8_t)(crc / 256);
    modbus.sendbuf[i++] = (uint8_t)(crc % 256);

    RS485_TX_ENABLE;
    for (i = 0; i < 5; i++) {
        Modbus_Send_Byte(modbus.sendbuf[i]);
    }
    RS485_RX_ENABLE;
}

void Modbus_Func3(void)
{
    uint16_t Regadd, Reglen, crc;
    uint8_t  i, j;

    Regadd = modbus.rcbuf[2] * 256 + modbus.rcbuf[3];
    Reglen = modbus.rcbuf[4] * 256 + modbus.rcbuf[5];

    /* Խ�籣������ʼ��ַԽ���Ĵ�������Ϊ0�������쳣֡�������Խ���/д�� */
    if (Regadd >= 128U || Reglen == 0U) {
        Modbus_Exception(0x03, 0x02);
        return;
    }
    /* Reg ����߽� */
    if (Reglen > (uint16_t)(128U - Regadd)) {
        Modbus_Exception(0x03, 0x02);
        return;
    }
    /* sendbuf[100] ������5 + 2*Reglen <= 100 -> Reglen <= 46 */
    if (Reglen > 46U) {
        Modbus_Exception(0x03, 0x02);
        return;
    }

    i = 0;
    modbus.sendbuf[i++] = modbus.myadd;
    modbus.sendbuf[i++] = 0x03;
    modbus.sendbuf[i++] = (uint8_t)((Reglen * 2) % 256);
    for (j = 0; j < Reglen; j++) {
        modbus.sendbuf[i++] = (uint8_t)(Reg[Regadd + j] / 256);
        modbus.sendbuf[i++] = (uint8_t)(Reg[Regadd + j] % 256);
    }
    crc = Modbus_CRC16(modbus.sendbuf, i);
    modbus.sendbuf[i++] = (uint8_t)(crc / 256);
    modbus.sendbuf[i++] = (uint8_t)(crc % 256);

    RS485_TX_ENABLE;
    for (j = 0; j < i; j++) {
        Modbus_Send_Byte(modbus.sendbuf[j]);
    }
    RS485_RX_ENABLE;
}

void Modbus_Func6_Broadcast(void)
{
    uint16_t Regadd;
    uint32_t val;

    Regadd = modbus.rcbuf[2] * 256 + modbus.rcbuf[3];
    val    = modbus.rcbuf[4] * 256 + modbus.rcbuf[5];

    if (Regadd < 128) {
        Reg[Regadd] = (uint16_t)val;
    }

    if (Regadd == 0x08) {
        uint32_t baud = 9600;
        if (val == 0) {
            baud = 9600;
        } else if (val == 1) {
            baud = 115200;
        } else {
            baud = 9600;
        }

        bound_add_write(val);
        Modbus_uart2_init(baud);
        delay_ms(100);
        nvic_system_reset();
    }
}

void Modbus_Func6(void)
{
    uint16_t Regadd;
    uint32_t val;
    uint16_t i, crc, j;

    i = 0;
    Regadd = modbus.rcbuf[2] * 256 + modbus.rcbuf[3];
    val    = modbus.rcbuf[4] * 256 + modbus.rcbuf[5];

    if (Regadd < 128) {
        Reg[Regadd] = (uint16_t)val;
    }

    modbus.sendbuf[i++] = modbus.myadd;
    modbus.sendbuf[i++] = 0x06;
    modbus.sendbuf[i++] = (uint8_t)(Regadd / 256);
    modbus.sendbuf[i++] = (uint8_t)(Regadd % 256);
    modbus.sendbuf[i++] = (uint8_t)(val / 256);
    modbus.sendbuf[i++] = (uint8_t)(val % 256);
    crc = Modbus_CRC16(modbus.sendbuf, i);
    modbus.sendbuf[i++] = (uint8_t)(crc / 256);
    modbus.sendbuf[i++] = (uint8_t)(crc % 256);

    RS485_TX_ENABLE;
    for (j = 0; j < i; j++) {
        Modbus_Send_Byte(modbus.sendbuf[j]);
    }
    delay_ms(100);

    if (Regadd == 0x08) {
        uint32_t baud = 9600;
        if (val == 0) {
            baud = 9600;
        } else if (val == 1) {
            baud = 115200;
        } else {
            baud = 9600;
        }
        bound_add_write(val);
        delay_ms(100);
        Modbus_uart2_init(baud);
        delay_ms(100);
        nvic_system_reset();
    } else if (Regadd == 0x10) {        /* �ӻ���ַ��1~99��д��EEPROM����λ */
        if (val != 0 && val < 100) {
            delay_ms(100);
            slave_add_write((uint16_t)val);
            delay_ms(100);
            nvic_system_reset();
        }
    } else if (Regadd == REG_PARAM_RADI) {
        if (val != 0 && val != 0xFFFF) {
            Param_Adj_Radi[0] = (unsigned int)val;
            Hx711_Save_Calibration();
        }
    } else if (Regadd == REG_PARAM_DIR) {
        if (val != 0 && val != 0xFFFF) {
            Param_Adj_Dir[0] = (unsigned int)val;
            Hx711_Save_Calibration();
        }
    } else if (Regadd == 0x11) {    /* IAP ����������д 0x1234 ����Bootloader */
        if (val == 0x1234) {
            IWDG_Feed();
            trigger_iap_update();
        }
    }
}

void Modbus_Func16_Broadcast(void)
{
    uint16_t Regadd, Reglen, i;

    Regadd = modbus.rcbuf[2] * 256 + modbus.rcbuf[3];
    Reglen = modbus.rcbuf[4] * 256 + modbus.rcbuf[5];

    /* Խ�籣����Reglen ���ó�����֡ʵ��Я������������ (recount-10)/2 */
    if (modbus.recount < 10U) {
        Reglen = 0U;
    } else if (Reglen > (uint16_t)((modbus.recount - 10U) / 2U)) {
        Reglen = (uint16_t)((modbus.recount - 10U) / 2U);
    }

    for (i = 0; i < Reglen; i++) {
        if (Regadd + i < 128) {
            Reg[Regadd + i] = modbus.rcbuf[7 + i * 2] * 256 + modbus.rcbuf[8 + i * 2];
        }
    }
}

void Modbus_Func16(void)
{
    uint16_t Regadd, Reglen;
    uint16_t i, crc, j;

    Regadd = modbus.rcbuf[2] * 256 + modbus.rcbuf[3];
    Reglen = modbus.rcbuf[4] * 256 + modbus.rcbuf[5];

    /* Խ�籣����Reglen ���ó�����֡ʵ��Я������������ (recount-10)/2 */
    if (modbus.recount < 10U) {
        Reglen = 0U;
    } else if (Reglen > (uint16_t)((modbus.recount - 10U) / 2U)) {
        Reglen = (uint16_t)((modbus.recount - 10U) / 2U);
    }

    for (i = 0; i < Reglen; i++) {
        if (Regadd + i < 128) {
            Reg[Regadd + i] = modbus.rcbuf[7 + i * 2] * 256 + modbus.rcbuf[8 + i * 2];
        }
    }

    if (Regadd <= REG_PARAM_RADI && REG_PARAM_RADI < Regadd + Reglen) {
        if (Reg[REG_PARAM_RADI] != 0 && Reg[REG_PARAM_RADI] != 0xFFFF) {
            Param_Adj_Radi[0] = Reg[REG_PARAM_RADI];
            Hx711_Save_Calibration();
        }
    }
    if (Regadd <= REG_PARAM_DIR && REG_PARAM_DIR < Regadd + Reglen) {
        if (Reg[REG_PARAM_DIR] != 0 && Reg[REG_PARAM_DIR] != 0xFFFF) {
            Param_Adj_Dir[0] = Reg[REG_PARAM_DIR];
            Hx711_Save_Calibration();
        }
    }
    modbus.sendbuf[0] = modbus.rcbuf[0];
    modbus.sendbuf[1] = modbus.rcbuf[1];
    modbus.sendbuf[2] = modbus.rcbuf[2];
    modbus.sendbuf[3] = modbus.rcbuf[3];
    modbus.sendbuf[4] = modbus.rcbuf[4];
    modbus.sendbuf[5] = modbus.rcbuf[5];
    crc = Modbus_CRC16(modbus.sendbuf, 6);
    modbus.sendbuf[6] = (uint8_t)(crc / 256);
    modbus.sendbuf[7] = (uint8_t)(crc % 256);

    RS485_TX_ENABLE;
    for (j = 0; j < 8; j++) {
        Modbus_Send_Byte(modbus.sendbuf[j]);
    }
    RS485_RX_ENABLE;
}

void Modbus_Event(void)
{
    uint16_t crc, rccrc;

    if (modbus.reflag == 0) {
        return;
    }

    if (modbus.recount < 8) {
        modbus.reflag  = 0;
        modbus.recount = 0;
        return;
    }

    crc = Modbus_CRC16(modbus.rcbuf, modbus.recount - 2);
    rccrc = modbus.rcbuf[modbus.recount - 2] * 256 + modbus.rcbuf[modbus.recount - 1];

    if (crc == rccrc) {
        if (modbus.rcbuf[0] == modbus.myadd) {
            uint8_t func = modbus.rcbuf[1];
            if (func != 3 && func != 6 && func != 16) {
                modbus.reflag  = 0;
                modbus.recount = 0;
                return;
            }
            switch (func) {
                case 3:  Modbus_Func3();  break;
                case 6:  Modbus_Func6();  break;
                case 16: Modbus_Func16(); break;
                default: break;
            }
        } else if (modbus.rcbuf[0] == 0) {
            uint8_t func = modbus.rcbuf[1];
            if (func != 6 && func != 16) {
                modbus.reflag  = 0;
                modbus.recount = 0;
                return;
            }
            switch (func) {
                case 6:  Modbus_Func6_Broadcast();  break;
                case 16: Modbus_Func16_Broadcast(); break;
                default: break;
            }
        }
    }

    modbus.recount = 0;
    modbus.reflag  = 0;
}